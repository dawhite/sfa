The NoData value for the aggregate viewshed is 0

